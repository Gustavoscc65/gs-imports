const products = [
  {id:"mizuno-prophecy-14",name:"Mizuno Wave Prophecy 14",price:379.99,old:799.99,category:"tenis",tag:"MIZUNO",img:"https://images.unsplash.com/photo-1600185365483-26d7a4cc7519?auto=format&fit=crop&w=800&q=80"},
  {id:"mizuno-prophecy-15",name:"Mizuno Wave Prophecy 15",price:449.99,old:799.99,category:"tenis",tag:"MIZUNO",img:"https://images.unsplash.com/photo-1552346154-21d32810aba3?auto=format&fit=crop&w=800&q=80"},
  {id:"adidas-grand-court",name:"Adidas Grand Court Base",price:199,old:270,category:"tenis",tag:"ADIDAS",img:"https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=800&q=80"},
  {id:"tommy-dino",name:"Tênis Tommy Hilfiger Dino",price:279.99,old:380,category:"tenis",tag:"TOMMY HILFIGER",img:"https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77?auto=format&fit=crop&w=800&q=80"},
  {id:"nike-dunk-twist",name:"Nike Dunk Twist",price:209.99,old:600,category:"tenis",tag:"NIKE",img:"https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=800&q=80"},
  {id:"nike-dunk-sb",name:"Nike Dunk Low SB",price:209.99,old:600,category:"tenis",tag:"NIKE",img:"https://images.unsplash.com/photo-1552346154-21d32810aba3?auto=format&fit=crop&w=800&q=80"},
  {id:"nike-shox-r4",name:"Nike Shox R4",price:279.99,old:350,category:"tenis",tag:"NIKE",img:"https://images.unsplash.com/photo-1600185365483-26d7a4cc7519?auto=format&fit=crop&w=800&q=80"},
  {id:"nike-court-vision",name:"Nike Court Vision Sola Alta",price:249,old:625,category:"tenis",tag:"NIKE",img:"https://images.unsplash.com/photo-1525966222134-fcfa99b8ae77?auto=format&fit=crop&w=800&q=80"},
  {id:"puma-bmw",name:"Puma CA Pro BMW",price:279.99,old:350,category:"tenis",tag:"PUMA",img:"https://images.unsplash.com/photo-1552346154-21d32810aba3?auto=format&fit=crop&w=800&q=80"},
  {id:"puma-mercedes",name:"Puma CA Pro Mercedes",price:279.99,old:350,category:"tenis",tag:"PUMA",img:"https://images.unsplash.com/photo-1600185365483-26d7a4cc7519?auto=format&fit=crop&w=800&q=80"},
  {id:"camiseta-lacoste",name:"Camiseta Lacoste Big Logo",price:99.98,old:140,category:"camisetas",tag:"LACOSTE",img:"https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=800&q=80"},
  {id:"camiseta-tommy",name:"Camiseta Tommy Hilfiger",price:229.99,old:330,category:"camisetas",tag:"TOMMY HILFIGER",img:"https://images.unsplash.com/photo-1503341504253-dff4815485f1?auto=format&fit=crop&w=800&q=80"},
  {id:"camiseta-nike",name:"Camiseta Nike Icon",price:99.80,old:330,category:"camisetas",tag:"NIKE",img:"https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=800&q=80"},
  {id:"camiseta-porsche",name:"Camiseta Porsche Boss",price:99.98,old:140,category:"camisetas",tag:"PORSCHE",img:"https://images.unsplash.com/photo-1503341504253-dff4815485f1?auto=format&fit=crop&w=800&q=80"},
  {id:"camiseta-armani",name:"Camiseta Empório Armani",price:99.98,old:140,category:"camisetas",tag:"ARMANI",img:"https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?auto=format&fit=crop&w=800&q=80"}
];
const money = v => v.toLocaleString("pt-BR",{style:"currency",currency:"BRL"});
let cart = JSON.parse(localStorage.getItem("gs-cart") || "[]");
const grid = document.getElementById("productGrid"), shirtGrid = document.getElementById("shirtGrid");
function productCard(p){return `<article class="product"><div class="product-photo"><img src="${p.img}" alt="${p.name}" loading="lazy"><span class="brand-tag">GS IMPORTS</span></div><div class="product-info"><span class="category">${p.category==="tenis"?"TÊNIS":"VESTUÁRIO"} • ${p.tag}</span><h3>${p.name}</h3><div><span class="price">${money(p.price)}</span><span class="old-price">${money(p.old)}</span></div><button class="add-btn" data-add="${p.id}">Adicionar à sacola</button></div></article>`}
function render(){grid.innerHTML=products.filter(p=>p.category==="tenis").slice(0,10).map(productCard).join("");shirtGrid.innerHTML=products.filter(p=>p.category==="camisetas").map(productCard).join("");updateCart()}
function updateCart(){localStorage.setItem("gs-cart",JSON.stringify(cart));document.getElementById("cartCount").textContent=cart.reduce((n,x)=>n+x.quantity,0);document.getElementById("cartTotal").textContent=money(cart.reduce((s,x)=>s+products.find(p=>p.id===x.id).price*x.quantity,0));const box=document.getElementById("cartItems");box.innerHTML=cart.length?cart.map(x=>{const p=products.find(p=>p.id===x.id);return `<div class="cart-row"><div><strong>${p.name}</strong><small>${money(p.price)} cada</small><button class="remove" data-remove="${p.id}">Remover</button></div><div class="qty"><button data-dec="${p.id}">−</button><b>${x.quantity}</b><button data-inc="${p.id}">+</button></div></div>`}).join(""):`<p class="empty">Sua sacola está vazia.</p>`}
function toast(msg){const t=document.getElementById("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2300)}
function openCart(){document.getElementById("cartPanel").classList.add("open");document.getElementById("overlay").classList.add("show")}
function closeCart(){document.getElementById("cartPanel").classList.remove("open");document.getElementById("overlay").classList.remove("show")}
document.addEventListener("click",e=>{const add=e.target.closest("[data-add]");if(add){const id=add.dataset.add;const item=cart.find(x=>x.id===id);item?item.quantity++:cart.push({id,quantity:1});updateCart();toast("Produto adicionado à sacola.");}
const inc=e.target.closest("[data-inc]");if(inc){cart.find(x=>x.id===inc.dataset.inc).quantity++;updateCart()}
const dec=e.target.closest("[data-dec]");if(dec){const item=cart.find(x=>x.id===dec.dataset.dec);item.quantity--;if(item.quantity<=0)cart=cart.filter(x=>x.id!==dec.dataset.dec);updateCart()}
const rem=e.target.closest("[data-remove]");if(rem){cart=cart.filter(x=>x.id!==rem.dataset.remove);updateCart()}
});
document.getElementById("openCart").onclick=openCart;document.getElementById("closeCart").onclick=closeCart;document.getElementById("overlay").onclick=closeCart;
document.getElementById("menuBtn").onclick=()=>document.getElementById("nav").classList.toggle("show");
document.querySelectorAll(".filter").forEach(b=>b.onclick=()=>{document.querySelectorAll(".filter").forEach(x=>x.classList.remove("active"));b.classList.add("active");const type=b.dataset.filter;grid.innerHTML=products.filter(p=>type==="all"?p.category==="tenis":p.category===type).map(productCard).join("");});
document.getElementById("checkoutBtn").onclick=()=>{if(!cart.length)return toast("Adicione um produto antes de finalizar.");closeCart();document.getElementById("buyerModal").classList.add("show")};
document.getElementById("closeBuyer").onclick=()=>document.getElementById("buyerModal").classList.remove("show");
document.getElementById("buyerForm").onsubmit=async e=>{e.preventDefault();const button=e.target.querySelector("button[type=submit]");button.disabled=true;button.textContent="Preparando pagamento...";const buyer=Object.fromEntries(new FormData(e.target).entries());try{const response=await fetch("/api/checkout",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({items:cart,buyer})});const data=await response.json();if(!response.ok)throw new Error(data.error||"Erro ao criar pagamento.");localStorage.removeItem("gs-cart");cart=[];window.location.href=data.checkoutUrl;}catch(err){toast(err.message);button.disabled=false;button.innerHTML='Ir para pagamento <span>↗</span>';}};
const params=new URLSearchParams(location.search);if(params.has("pedido"))toast("Pedido "+params.get("pedido")+" recebido. A confirmação será atualizada após retorno do PagBank.");
render();
